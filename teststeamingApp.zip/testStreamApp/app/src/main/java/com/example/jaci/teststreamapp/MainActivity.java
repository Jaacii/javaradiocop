package com.example.jaci.teststreamapp;

import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.VideoView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener
    {

        boolean radioplaying = false;
     private static WebView webview ;
        String url = "192:168:0:192.8081";

        @Override
        protected void onCreate (Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // RADIO BUTTON INIT
        Button radiobtn = (Button)findViewById(R.id.radiobtn);
        radiobtn.setOnClickListener(this);

        // VIDEO REFRESH
        Button videobtn = (Button)findViewById(R.id.radiobtn);
        videobtn.setOnClickListener(this);


        /* alternative
        new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                radiotoggled();
            }
        });*/



        //Video/ LIVESTREAM START       falls webview nicht klappt
        /*Uri uri = Uri.parse("192:168:0:192.8081");
        VideoView videoView = findViewById(R.id.videoView);
        videoView.setVideoURI(uri);

        videoView.start();*/
        webview =(WebView) findViewById(R.id.webview);

        webview.getSettings().getJavaScriptEnabled();
        webview.loadUrl(url);
    }





       public void videoaction() {
           webview.loadUrl(url);
       }




       public void radiotoggled() {
           //radio ausschalten RADIO KLASSE ODER PI
           if (!radioplaying) {
               radioplaying = true;

               //radio anschalten  RADIO KLASSE ODER PI
           } else {
               radioplaying = false;
           }
       }

        @Override
        public void onClick(View v) {
            switch (v.getId()) {
                case R.id.radiobtn:
                    radiotoggled();
                    break;


                case R.id.videobtn:
                    videoaction();

                    break;




                case R.id.forward:
                    //FORWARD

                    break;

                case R.id.backward:
                    //BACKWARD

                    break;

                case R.id.left:
                    //LEFT

                    break;

                case R.id.stop:
                    //STOP

                    break;

                case R.id.right:
                    //RIGHT

                    break;

            }
        }
    }
