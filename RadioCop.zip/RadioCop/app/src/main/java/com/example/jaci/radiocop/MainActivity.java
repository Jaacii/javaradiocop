package com.example.jaci.radiocop;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.ImageButton;

import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.android.service.MqttAndroidClient;
import org.eclipse.paho.client.mqttv3.DisconnectedBufferOptions;
import org.eclipse.paho.android.service.MqttAndroidClient;
import org.eclipse.paho.client.mqttv3.IMqttActionListener;
import org.eclipse.paho.client.mqttv3.IMqttToken;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;

import java.io.UnsupportedEncodingException;

public class MainActivity extends AppCompatActivity implements View.OnClickListener
{

    boolean radioplaying = false;
    private static WebView webview ;
    String url = "192.168.0.192:8081";
    String url2 ="https://www.google.com/search?q=androidstudio+layout+&ie=utf-8&oe=utf-8&client=firefox-b-ab";
    private MqttAndroidClient client;
    private final MemoryPersistence persistence = new MemoryPersistence();
    //String brokerurl = "broker.mqttdashboard.com"
    //String topic = "haw/dmi/mt/its/ss18"
    boolean connected = false;
    String topic = "haw/dmi/mt/its/ss18/radiocop";

    @Override
    protected void onCreate (Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        //MQTT start
/*
        MqttClient client = new MqttClient(
                "tcp://broker.mqttdashboard.com:8000", //URI
                MqttClient.generateClientId(), //ClientId
                new MemoryPersistence()); //Persistence
*/
        String clientId = MqttClient.generateClientId();
        MqttAndroidClient client =
                new MqttAndroidClient(this.getApplicationContext(), "tcp://broker.hivemq.com:1883",
                        clientId);

        try {
            IMqttToken token = client.connect();
            token.setActionCallback(new IMqttActionListener() {
                @Override
                public void onSuccess(IMqttToken asyncActionToken) {
                    // We are connected
                //    Log.d(TAG, "onSuccess");
                }

                @Override
                public void onFailure(IMqttToken asyncActionToken, Throwable exception) {
                    // Something went wrong e.g. connection timeout or firewall problems
                  //  Log.d(TAG, "onFailure");

                }
            });
        } catch (MqttException e) {
            e.printStackTrace();
        }






        ////MQTT end

        // RADIO BUTTON INIT
        ImageButton radiobtn = (ImageButton)findViewById(R.id.radiobtn);
        radiobtn.setOnClickListener(this);

        // VIDEO REFRESH
        ImageButton videobtn = (ImageButton)findViewById(R.id.videobtn);
        videobtn.setOnClickListener(this);


        //Buttons
        ImageButton forward =(ImageButton) findViewById(R.id.forward);
        ImageButton backward =(ImageButton) findViewById(R.id.backward);
        ImageButton left =(ImageButton) findViewById(R.id.left);
        ImageButton right =(ImageButton) findViewById(R.id.right);
        ImageButton stop =(ImageButton) findViewById(R.id.stop);
        ImageButton camR =(ImageButton) findViewById(R.id.CamR);
        ImageButton camL =(ImageButton) findViewById(R.id.CamL);

        /* alternative
        new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                radiotoggled();
            }
        });*/



        //Video/ LIVESTREAM START       falls webview nicht klappt
        /*Uri uri = Uri.parse("192:168:0:192.8081");
        VideoView videoView = findViewById(R.id.videoView);
        videoView.setVideoURI(uri);

        videoView.start();*/
        webview =(WebView) findViewById(R.id.webview);
        webview();

    }




/*

        public MqttAndroidClient getMqttClient(Context context, String brokerUrl, String clientId) {
            MqttAndroidClient  mqttAndroidClient = new MqttAndroidClient(context, brokerUrl, clientId);
            try {
                IMqttToken token = mqttAndroidClient.connect(getMqttConnectionOption());
                token.setActionCallback(new IMqttActionListener() {
                    @Override
                    public void onSuccess(IMqttToken asyncActionToken) {
                        mqttAndroidClient.setBufferOpts(getDisconnectedBufferOptions());
                        Log.d(TAG, "Success");
                    }

                    @Override
                    public void onFailure(IMqttToken asyncActionToken, Throwable exception) {
                        Log.d(TAG, "Failure " + exception.toString());
                    }
                });
            } catch (MqttException e) {
                e.printStackTrace();
            }
            return mqttAndroidClient;
        }
*/


    public void webview() {
        webview.setWebViewClient(new WebViewClient());
        webview.getSettings().getJavaScriptEnabled();
        webview.loadUrl(url);
    }

    public void videoaction() {
        webview.loadUrl(url);
    }




    public void radiotoggled() {
        //radio ausschalten RADIO KLASSE ODER PI
        if (!radioplaying) {
            radioplaying = true;
            //radio an     sendefunktion für mqtt hier einfügen

            //radio anschalten  RADIO KLASSE ODER PI
        } else {
            radioplaying = false;
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.radiobtn:
                radiotoggled();
                break;


            case R.id.videobtn:
                videoaction();

                break;




            case R.id.forward:
                //FORWARD

                    publishMessage(client, "forward", 1, topic );

                break;

            case R.id.backward:
                //BACKWARD
                publishMessage(client, "back", 1, topic );
                break;

            case R.id.left:
                //LEFT
                publishMessage(client, "links", 1, topic );

                break;

            case R.id.stop:
                //STOP

                    publishMessage(client, "stop", 1, topic );

                break;

            case R.id.right:
                //RIGHT

                    publishMessage(client, "rechts", 1, topic );

                break;
            case R.id.CamL:
                //FORWARD

                    publishMessage(client, "CamL", 1, topic );

                break;
            case R.id.CamR:
                //FORWARD

                    publishMessage(client, "CamR", 1, topic );

                break;

        }
    }

    public void publishMessage(@NonNull MqttAndroidClient client,@NonNull String msg, int qos, @NonNull String topic) {

        String payload = "the payload";
        byte[] encodedPayload = new byte[0];
        try {
            encodedPayload = payload.getBytes("UTF-8");
            MqttMessage message = new MqttMessage(encodedPayload);
            client.publish(topic, message);
        } catch (UnsupportedEncodingException | MqttException e) {
            e.printStackTrace();
        }
    }

/*
    public void publishMessage(@NonNull MqttAndroidClient client,
                               @NonNull String msg, int qos, @NonNull String topic)
            throws MqttException, UnsupportedEncodingException {
        byte[] encodedPayload = new byte[0];
        encodedPayload = msg.getBytes("UTF-8");
        MqttMessage message = new MqttMessage(encodedPayload);
        message.setId(5866);
        message.setRetained(true);
        message.setQos(qos);
        client.publish(topic, message);
    }*/
}
