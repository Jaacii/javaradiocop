package com.example.jaci.radiocop;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;

public class MainActivity extends AppCompatActivity implements View.OnClickListener
{

    boolean radioplaying = false;
    private static WebView webview ;
    String url = "192:168:0:192.8081";
    String url2 ="https://www.google.com/search?q=androidstudio+layout+&ie=utf-8&oe=utf-8&client=firefox-b-ab";

    @Override
    protected void onCreate (Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // RADIO BUTTON INIT
        Button radiobtn = (Button)findViewById(R.id.radiobtn);
        radiobtn.setOnClickListener(this);

        // VIDEO REFRESH
        Button videobtn = (Button)findViewById(R.id.videobtn);
        videobtn.setOnClickListener(this);


        //Buttons
        Button forward =(Button) findViewById(R.id.forward);
        Button backward =(Button) findViewById(R.id.backward);
        Button left =(Button) findViewById(R.id.left);
        Button right =(Button) findViewById(R.id.right);
        Button stop =(Button) findViewById(R.id.stop);
        //Button camR =(Button) findViewById(R.id.right);
        // Button camL =(Button) findViewById(R.id.right);

        /* alternative
        new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                radiotoggled();
            }
        });*/



        //Video/ LIVESTREAM START       falls webview nicht klappt
        /*Uri uri = Uri.parse("192:168:0:192.8081");
        VideoView videoView = findViewById(R.id.videoView);
        videoView.setVideoURI(uri);

        videoView.start();*/
        webview =(WebView) findViewById(R.id.webview);
        webview();

    }





    public void mqttcreate() {

    }


    public void webview() {
        webview.setWebViewClient(new WebViewClient());
        webview.getSettings().getJavaScriptEnabled();
        webview.loadUrl(url2);
    }

    public void videoaction() {
        webview.loadUrl(url2);
    }




    public void radiotoggled() {
        //radio ausschalten RADIO KLASSE ODER PI
        if (!radioplaying) {
            radioplaying = true;
            //radio an     sendefunktion für mqtt hier einfügen

            //radio anschalten  RADIO KLASSE ODER PI
        } else {
            radioplaying = false;
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.radiobtn:
                radiotoggled();
                break;


            case R.id.videobtn:
                videoaction();

                break;




            case R.id.forward:
                //FORWARD
                //    sendefunktion für mqtt hier einfügen
                break;

            case R.id.backward:
                //BACKWARD

                break;

            case R.id.left:
                //LEFT

                break;

            case R.id.stop:
                //STOP

                break;

            case R.id.right:
                //RIGHT

                break;

        }
    }
}
