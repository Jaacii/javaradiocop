import os
import time

def radio_an():
	
	os.system("sudo /home/pi/Radio2/Radio")


def radio_aus():
	
	os.system("sudo /home/pi/Radio2/Radio_off")


def ndr():

	os.system("sudo /home/pi/Radio2/NDR")

def neunzigkommadrei():
	os.system("sudo /home/pi/Radio2/DELTA")

def sthh():
	os.system("sudo /home/pi/Radio2/StHH")


