import RPi.GPIO as GPIO
import time

GPIO.setwarnings(False)
GPIO.setmode(GPIO.BOARD)

GPIO.setup(12, GPIO.OUT)

p = GPIO.PWM(12, 50)

p.start(12.5) #dies beeinflusst wahrscheinlich den speed. evtl ändern
#time.sleep(1)
#p.ChangeDutyCycle(17.5) # unsicher ob richtige zahl. später zahl senken und mehrfach ausführen solange taste gedrückt wird.
		# time.sleep(1) # sleep 1 second
time.sleep(2)
			  # if p.dutyCycle == 7.5 :							#evtl falsch?
			  # p.stop()
			  # break

p.stop()
GPIO.cleanup()
	#muss später wahrscheinlch verändert werden
