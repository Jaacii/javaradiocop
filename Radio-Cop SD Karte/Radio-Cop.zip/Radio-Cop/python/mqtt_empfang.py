import paho.mqtt.client as mqtt
import time
import os
url = "broker.mqttdashboard.com"
topic = "haw/dmi/mt/its/ss18/radiocop"
port = 1883
# 1883   default port
#from forwards import *
#from cam_left import *
#from cam_right import *
#from links_motorsteuerung import *
#from rechts_motorsteuerung import *
#from backwards import *
from aufraeumen import *
from setup import *
from servo import *
from radio import *



def on_connect(client, userdata, flags, rc):
	print("Connected with result code "+str(rc))
	client.subscribe(topic)
	pr.start(40)
	pl.start(40)


def on_message(client, userdata, msg):
	payload = msg.payload.decode('utf-8')
	if payload == 'stop':
		print("Stop")
		bremsen()
		#pr.start(40)
		#pl.start(40)
	elif payload == 'forward':
		print("Start")
		losfahren()
	elif payload == 'back':
                print("Rückwärts")
                back()
	elif payload == 'links':
		print("links")
		links()
	elif payload == 'rechts':
		print("rechts")
		rechts()
	elif payload == 'CamR':
		print("Cam right")
		cright()
	elif payload == 'CamL':
		print("Cam left")
		cleft()
	elif payload == 'radioAn':
		print("Radio")
		radio_an()
	elif payload == 'RadioAus':
		print("Radio")
		bremsen()
		radio_aus()
	elif payload == '903': 
		print("NDR 90,3")
		bremsen()
		neunzigkommadrei()
	elif payload == 'ndr':
		print("NDR")
		bremsen()
		ndr()
	elif payload == 'sthh':
		print("Radio HH")
		bremsen()
		sthh()
	elif payload == 'reload':
		print("Reload")
		#os.system('sudo service motion restart')

	else:
		print("unbekannter Befehl")


#Hier gehts los    paho.client? mqtt.client
client = mqtt.Client("", True, None, mqtt.MQTTv31) #Client object
client.on_connect = on_connect #Callbacks registrieren
client.on_message = on_message

client.connect(url, port, 60) #Connect
#client.loop_forever() #Abarbeiten von Paketen

try:
	while 1:
		client.loop_forever()

except KeyboardInterrupt:
	bremsen()
	aufraeumen()
	GPIO.cleanup()
