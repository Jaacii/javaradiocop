package com.example.jaci.javaradiocop;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.SurfaceHolder;

public class viewVideo {

    private SurfaceHolder surfaceholder;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        //SurfaceHolder surfaceholder = holder;
        surfaceholder.addCallback(this);

    }

    public surfaceCreated (SurfaceHolder surfaceholder) {

    }
    public surfaceChanged (SurfaceHolder surfaceholder, int i, int ii, int iii) {

    }
    public surfaceDestroyed(SurfaceHolder surfaceholder) {

    }


    public drawCanvas (float left, float right, float top, float bottom) {
        Canvas canvas = surfaceholder.lockCanvas();
        Paint paint;

        paint.style = Paint.Style.FILL;
        paint.color = Color.GREEN;    //?
        Canvas.drawRGB(128, 128, 128);
        canvas.drawRect(left, top, right, bottom, paint);


    }
}
