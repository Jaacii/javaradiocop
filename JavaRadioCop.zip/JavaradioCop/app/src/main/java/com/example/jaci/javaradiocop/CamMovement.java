package com.example.jaci.javaradiocop;

public class CamMovement {

    public void moveCam() {
        //Pi anbindung setzen
    }
}
